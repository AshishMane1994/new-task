import { Info } from './info';

describe('Info', () => {
  it('should create an instance', () => {
    expect(new Info()).toBeTruthy();
  });
});
