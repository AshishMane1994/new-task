export class Info {
  
        firstname!: string;
        middlename!: string;
        lastname!: string;
        gender!: string;
        birthdate!: string;
        city!: string;
        state!: string;
        country!: string;
        zip!: number;
    
}
